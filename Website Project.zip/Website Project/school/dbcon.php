<?php
$conn = mysqli_connect('localhost','root','','bilal') or die(mysqli_error());
?>
