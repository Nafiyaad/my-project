<center>
<hr>

		<footer>
           <p>All Rights Reserved 2016 </p>
        <footer>
</center>