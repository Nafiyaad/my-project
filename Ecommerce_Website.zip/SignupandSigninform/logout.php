<?php

session_destroy();
header("location: signUp.php")
?>