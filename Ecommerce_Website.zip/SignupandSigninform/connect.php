<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "login";

// Create connection
$conn = mysqli_connect($servername, $username, $password, $dbname);
// Check connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}
echo "Connected successfully";
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
   <h1>
   <?php
 if($conn === true){
    echo "You didi good";
    }
    elseif($conn ->connect_error){
        echo "Failed to connect DB".$conn->connect_error;
    }
    ?>
   </h1>
   <h1>Heloo world</h1>
</body>
</html>