<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>e-commerce website</title>
  
    <link rel="stylesheet" href="style.css">

    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
</head>
<body>
    
    <section id="header">
        <a href="#"><img src="img/logo/favicon.ico" class="logo" width="80" height="80"></a>
    <div>
    <ul id="navbar">
<li><a  href="index.html">Home</a></li>
<li><a class="active" href="shop.html">Shop</a></li>
<li><a href="blog.html">Blog</a></li>
<li><a href="about.html">About</a></li>
<li><a href="contact.html">Contact</a></li>
<li id="lg-bag"><a href="cart.html"></a><i class='bx bx-shopping-bag'></i></li>
<a href="#" id="close"><i class='bx bx-window-close'></i></a>
    </ul>
    </div>
    <div id="mobile">
       
    <a href="cart.html"></a><i class='bx bx-shopping-bag'></i>
    <i id="bar" class='bx bx-menu'></i>
</div>
    </section>
    
    <section id="page-header">
       <h2>#stayhome</h2>
        <p>Save more with coupons & up to 70% off!</p>
     
        </div>
      
    </section>



<section id="product1" class="section-1">
   

<div class="Pro-container">
    <!--anyone click it it goes(redarecting )to small product details-->
    <div class="pro" onclick="window.location.href ='Sproduct.html';"> 
    <img src="img/pro1.png" width="160" height="160"><br>
    <span>Adidas</span>
    <h5>Cartoon Astronaut T-Shirt</h5>
    <div class="star">
        <i class='bx bxs-star'></i>
        <i class='bx bxs-star'></i>
        <i class='bx bxs-star'></i>
        <i class='bx bxs-star'></i>
        <i class='bx bxs-star'></i>
        <h4>$78</h4>
        <a href="#"><i class='bx bx-cart-alt cart'></i></a>
    </div>
    </div>
   
    
    <div class="pro">
     <!-- onclick="window.location.href ='Sproduct.html';">  
         -->
        <img src="img/pro2.png" width="190" height="190"><br>
        <span>Adidas</span>
        <h5>Cartoon Astronaut T-Shirt</h5>
        <div class="star">
            <i class='bx bxs-star'></i>
            <i class='bx bxs-star'></i>
            <i class='bx bxs-star'></i>
            <i class='bx bxs-star'></i>
            <i class='bx bxs-star'></i>
            <h4>$78</h4>
            <a href="#"><i class='bx bx-cart-alt cart'></i></a>
        </div>
        </div>

        <div class="pro"> 
            <img src="img/pro3.png" width="190" height="190"><br>
            <span>Adidas</span>
            <h5>Cartoon Astronaut T-Shirt</h5>
            <div class="star">
                <i class='bx bxs-star'></i>
                <i class='bx bxs-star'></i>
                <i class='bx bxs-star'></i>
                <i class='bx bxs-star'></i>
                <i class='bx bxs-star'></i>
                <h4>$78</h4>
                <a href="#"><i class='bx bx-cart-alt cart'></i></a>
            </div>
            </div>

            <div class="pro"> 
                <img src="img/pro4.png" width="190" height="190"><br>
                <span>Adidas</span>
                <h5>Cartoon Astronaut T-Shirt</h5>
                <div class="star">
                    <i class='bx bxs-star'></i>
                    <i class='bx bxs-star'></i>
                    <i class='bx bxs-star'></i>
                    <i class='bx bxs-star'></i>
                    <i class='bx bxs-star'></i>
                    <h4>$78</h4>
                    <a href="#"><i class='bx bx-cart-alt cart'></i></a>
                </div>
                </div>

                <div class="pro"> 
                    <img src="img/pro5.png" width="190" height="190"><br>
                    <span>Adidas</span>
                    <h5>Cartoon Astronaut T-Shirt</h5>
                    <div class="star">
                        <i class='bx bxs-star'></i>
                        <i class='bx bxs-star'></i>
                        <i class='bx bxs-star'></i>
                        <i class='bx bxs-star'></i>
                        <i class='bx bxs-star'></i>
                        <h4>$78</h4>
                        <a href="#"><i class='bx bx-cart-alt cart'></i></a>
                    </div>
                    </div>

                    <div class="pro"> 
                        <img src="img/pro6.png" width="190" height="190"><br>
                        <span>Adidas</span>
                        <h5>Cartoon Astronaut T-Shirt</h5>
                        <div class="star">
                            <i class='bx bxs-star'></i>
                            <i class='bx bxs-star'></i>
                            <i class='bx bxs-star'></i>
                            <i class='bx bxs-star'></i>
                            <i class='bx bxs-star'></i>
                            <h4>$78</h4>
                            <a href="#"><i class='bx bx-cart-alt cart'></i></a>
                        </div>
                        </div>

                        <div class="pro"> 
                            <img src="img/pro7.png" width="190" height="190"><br>
                            <span>Adidas</span>
                            <h5>Cartoon Astronaut T-Shirt</h5>
                            <div class="star">
                                <i class='bx bxs-star'></i>
                                <i class='bx bxs-star'></i>
                                <i class='bx bxs-star'></i>
                                <i class='bx bxs-star'></i>
                                <i class='bx bxs-star'></i>
                                <h4>$78</h4>
                                <a href="#"><i class='bx bx-cart-alt cart'></i></a>
                            </div>
                            </div>

                            <div class="pro"> 
                                <img src="img/pro26.png" width="190" height="190"><br>
                                <span>Adidas</span>
                                <h5>Cartoon Astronaut T-Shirt</h5>
                                <div class="star">
                                    <i class='bx bxs-star'></i>
                                    <i class='bx bxs-star'></i>
                                    <i class='bx bxs-star'></i>
                                    <i class='bx bxs-star'></i>
                                    <i class='bx bxs-star'></i>
                                    <h4>$78</h4>
                                    <a href="#"><i class='bx bx-cart-alt cart'></i></a>
                                </div>
                                </div>

                                <div class="pro"> 
                                    <img src="img/pro9.png" width="190" height="190"><br>
                                    <span>Adidas</span>
                                    <h5>Cartoon Astronaut T-Shirt</h5>
                                    <div class="star">
                                        <i class='bx bxs-star'></i>
                                        <i class='bx bxs-star'></i>
                                        <i class='bx bxs-star'></i>
                                        <i class='bx bxs-star'></i>
                                        <i class='bx bxs-star'></i>
                                        <h4>$78</h4>
                                        <a href="#"><i class='bx bx-cart-alt cart'></i></a>
                                    </div>
                                    </div>

                                    <div class="pro"> 
                                        <img src="img/pro33.png" width="190" height="190"><br>
                                        <span>Adidas</span>
                                        <h5>Cartoon Astronaut T-Shirt</h5>
                                        <div class="star">
                                            <i class='bx bxs-star'></i>
                                            <i class='bx bxs-star'></i>
                                            <i class='bx bxs-star'></i>
                                            <i class='bx bxs-star'></i>
                                            <i class='bx bxs-star'></i>
                                            <h4>$78</h4>
                                            <a href="#"><i class='bx bx-cart-alt cart'></i></a>
                                        </div>
                                        </div>
            




<!--<section id="product1" class="section-1">
    <h1>New Arrivals</h1>
   <!-- <p>Summer Collection New Modern Design</p>
<div class="Pro-container">
    <div class="pro"> 
    <img src="img/newA1.png" width="190" height="190"><br>
    <span>Adidas</span>
    <h5>Cartoon Astronaut T-Shirt</h5>
    <div class="star">
        <i class='bx bxs-star'></i>
        <i class='bx bxs-star'></i>
        <i class='bx bxs-star'></i>
        <i class='bx bxs-star'></i>
        <i class='bx bxs-star'></i>
        <h4>$78</h4>
        <a href="#"><i class='bx bx-cart-alt cart'></i></a>
    </div>
    </div>-->
   
    <div class="pro"> 
        <img src="img/newA1.png" width="190" height="190"><br>
        <span>Adidas</span>
        <h5>Cartoon Astronaut T-Shirt</h5>
        <div class="star">
            <i class='bx bxs-star'></i>
            <i class='bx bxs-star'></i>
            <i class='bx bxs-star'></i>
            <i class='bx bxs-star'></i>
            <i class='bx bxs-star'></i>
            <h4>$78</h4>
            <a href="#"><i class='bx bx-cart-alt cart'></i></a>
        </div>
        </div>

        <div class="pro"> 
            <img src="img/newA2.png" width="190" height="190"><br>
            <span>Adidas</span>
            <h5>Cartoon Astronaut T-Shirt</h5>
            <div class="star">
                <i class='bx bxs-star'></i>
                <i class='bx bxs-star'></i>
                <i class='bx bxs-star'></i>
                <i class='bx bxs-star'></i>
                <i class='bx bxs-star'></i>
                <h4>$78</h4>
                <a href="#"><i class='bx bx-cart-alt cart'></i></a>
            </div>
            </div>

            <div class="pro"> 
                <img src="img/newA3.png" width="190" height="190"><br>
                <span>Adidas</span>
                <h5>Cartoon Astronaut T-Shirt</h5>
                <div class="star">
                    <i class='bx bxs-star'></i>
                    <i class='bx bxs-star'></i>
                    <i class='bx bxs-star'></i>
                    <i class='bx bxs-star'></i>
                    <i class='bx bxs-star'></i>
                    <h4>$78</h4>
                    <a href="#"><i class='bx bx-cart-alt cart'></i></a>
                </div>
                </div>

                <div class="pro"> 
                    <img src="img/newA4.png" width="190" height="190"><br>
                    <span>Adidas</span>
                    <h5>Cartoon Astronaut T-Shirt</h5>
                    <div class="star">
                        <i class='bx bxs-star'></i>
                        <i class='bx bxs-star'></i>
                        <i class='bx bxs-star'></i>
                        <i class='bx bxs-star'></i>
                        <i class='bx bxs-star'></i>
                        <h4>$78</h4>
                        <a href="#"><i class='bx bx-cart-alt cart'></i></a>
                    </div>
                    </div>

                    <div class="pro"> 
                        <img src="img/pro5.png" width="190" height="190"><br>
                        <span>Adidas</span>
                        <h5>Cartoon Astronaut T-Shirt</h5>
                        <div class="star">
                            <i class='bx bxs-star'></i>
                            <i class='bx bxs-star'></i>
                            <i class='bx bxs-star'></i>
                            <i class='bx bxs-star'></i>
                            <i class='bx bxs-star'></i>
                            <h4>$78</h4>
                            <a href="#"><i class='bx bx-cart-alt cart'></i></a>
                        </div>
                        </div>

                        <div class="pro"> 
                            <img src="img/pro12.png" width="190" height="190"><br>
                            <span>Adidas</span>
                            <h5>Cartoon Astronaut T-Shirt</h5>
                            <div class="star">
                                <i class='bx bxs-star'></i>
                                <i class='bx bxs-star'></i>
                                <i class='bx bxs-star'></i>
                                <i class='bx bxs-star'></i>
                                <i class='bx bxs-star'></i>
                                <h4>$78</h4>
                                <a href="#"><i class='bx bx-cart-alt cart'></i></a>
                            </div>
                            </div>

                            <div class="pro"> 
                                <img src="img/newA4.png" width="140" height="140"><br>
                                <span>Adidas</span>
                                <h5>Cartoon Astronaut T-Shirt</h5>
                                <div class="star">
                                    <i class='bx bxs-star'></i>
                                    <i class='bx bxs-star'></i>
                                    <i class='bx bxs-star'></i>
                                    <i class='bx bxs-star'></i>
                                    <i class='bx bxs-star'></i>
                                    <h4>$78</h4>
                                    <a href="#"><i class='bx bx-cart-alt cart'></i></a>
                                </div>
                                </div>

                                <div class="pro"> 
                                    <img src="img/newA1.png" width="190" height="190"><br>
                                    <span>Adidas</span>
                                    <h5>Cartoon Astronaut T-Shirt</h5>
                                    <div class="star">
                                        <i class='bx bxs-star'></i>
                                        <i class='bx bxs-star'></i>
                                        <i class='bx bxs-star'></i>
                                        <i class='bx bxs-star'></i>
                                        <i class='bx bxs-star'></i>
                                        <h4>$78</h4>
                                        <a href="#"><i class='bx bx-cart-alt cart'></i></a>
                                    </div>
                                    </div>

                                    <div class="pro"> 
                                        <img src="img/pro26.png" width="190" height="190"><br>
                                        <span>Adidas</span>
                                        <h5>Cartoon Astronaut T-Shirt</h5>
                                        <div class="star">
                                            <i class='bx bxs-star'></i>
                                            <i class='bx bxs-star'></i>
                                            <i class='bx bxs-star'></i>
                                            <i class='bx bxs-star'></i>
                                            <i class='bx bxs-star'></i>
                                            <h4>$78</h4>
                                            <a href="#"><i class='bx bx-cart-alt cart'></i></a>
                                        </div>
                                        </div>
                                        <div class="pro"> 
                                            <img src="img/pro19.png" width="190" height="190"><br>
                                            <span>Adidas</span>
                                            <h5>Cartoon Astronaut T-Shirt</h5>
                                            <div class="star">
                                                <i class='bx bxs-star'></i>
                                                <i class='bx bxs-star'></i>
                                                <i class='bx bxs-star'></i>
                                                <i class='bx bxs-star'></i>
                                                <i class='bx bxs-star'></i>
                                                <h4>$78</h4>
                                                <a href="#"><i class='bx bx-cart-alt cart'></i></a>
                                            </div>
                                            </div>
            
    
    </div>
</div>
</section>

 <section id="pagination" class="section-1">
    
    <!--pagination for shopping page-->
    <a href="#">1</a>
    <a href="#">2</a>
    <a href="#"><i class='bx bx-right-arrow-alt'></i></a>

 </section>



<section id="newsletter" class="section-p1 section-m1">
    <div class="newstext">
        <h4>Sign Up For Newsletters</h4>
        <p>Get E-mail updates about our latest shop and <span>special offers.</span></p>
    </div>
 <div class="form">
    <input type="text" placeholder="Your email address">
    <button class="normal">Sign Up</button>
 </div>
</section>

<footer class="section-p1">
    <div class="col">
        <img class="logo" src="img/logo/favicon.ico" width="80" height="80">
        <h4>Contact</h4>
        <p><strong>Address:</strong> 562 Wellington Road, Street 32, San Francisco</p>
        <p><strong>Phone:</strong> +01 2222 365 /(+91) 01 2345 6789</p>
        <p><strong>Hours:</strong>10:00 - 18:00, Mon-Sat </p>
       <div class="follow">
        <h4>Follow us</h4>
        <div class="icon">
            <i class='bx bxl-facebook-circle'></i>
            <i class='bx bxl-twitter'></i>
            <i class='bx bxl-instagram-alt'></i>
            <i class='bx bxl-pinterest-alt'></i>
            <i class='bx bxl-youtube' ></i>
        </div>
       </div>
    </div>
<div class="col">
    <h4>About</h4>
    <a  href="#">Delivery Information</a>
    <a href="#">Privacy Policy</a>
    <a href="#">Terms & Conditions</a>
    <a href="#">Contact Us</a>
</div>
<div class="col">
    <h4>My Account</h4>
    <a  href="#">Sign In</a>
    <a href="#">View Cart</a>
    <a href="#">My Wishlist</a>
    <a href="#">Track My Order</a>
    <a href="#">Help</a>
</div>

<div class="col install">
    <h4>Install App</h4>
    <p>From App Store or Google Play</p>
    <div class="row">
        <img src="img/appstore.png" alt="">
        <img src="img/playstore.png" alt="">
    </div>
    <p>Secured Payment Gateways</p>
    <img src="img/payment.png" alt="">
</div>


<div class="copyright">
    <p>Copyright @2021</p>
</div>
</footer>


<script src="script.js"></script>
</body>
</html>