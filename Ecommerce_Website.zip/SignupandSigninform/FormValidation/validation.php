<?php
//$username = $_POST['username'];

//$email = $_POST['email'];

//$password = $_POST['password'];

$username = filter_input(INPUT_POST, 'username');
$email = filter_input(INPUT_POST, 'email');
$password = filter_input(INPUT_POST, 'password');

if(empty($username)){
    $name_error = 'please insert your username';
}
elseif(strlen($username)< 6 ){
    $name_error = 'your username needs to have a minimum  of 6 letters';
}

if(empty($email)){
    $email_error = 'please insert your email';
}
elseif(strlen($username)< 6 ){
    $email_error = 'your email needs to have a minimum  of 6 letters';
}


if(empty($password)){
    $password_error = 'please insert your password';
}
elseif(strlen($password)< 6 ){
    $password_error = 'your password needs to have a minimum  of 6 numbers';
}

if(empty($user_error)&& empty($password_error)){
    include('success.php');
}
else{
    include('form.php');
}






?>
