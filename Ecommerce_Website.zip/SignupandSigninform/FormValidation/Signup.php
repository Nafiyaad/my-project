<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Registration form</title>
    <!-- <link rel="stylesheet" href="styleSignup.css"/> -->
    <link rel="stylesheet" href="styleSignUp2.css">
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'> 
    
   
</head>
<body>
<!-- Sign Up Form -->
 <div class="container" id="signUp" style="display: none">
    <h1 class="form-title">Register</h1>
    <form method="post" action="">
        <div class="input-group">
            <i class='bx bxs-user'></i>
            <input type="text" name="Fname" id="fname" placeholder="Frist Name" required>
            <label for="fname">First Name</label>
        </div>
            <div class="input-group">
                <i class='bx bxs-user'></i>
                <input type="text" name="Lname" id="fname" placeholder="Last Name" required>
                <label for="fname">Last Name</label>
            </div>
                <div class="input-group">
                    <i class='bx bxs-envelope'></i>
                    <input type="text" name="email" id="email" placeholder="Email" required>
                    <label for="fname">Email</label>
                </div>
                <div class="input-group">
                    <i class='bx bxs-lock-alt'></i>
                    <input type="text" name="password" id="password" placeholder="password" required>
                    <label for="password">password</label>
                </div>
           <input type="submit" class="btn" value="Sign Up" name="Sign up">
        
    </form>
    <div class="links">
        <p>Already Have Account?</p>
        <button id="signInButton">Sign In</button>
    </div>
 </div>

   <!-- Sign In Form -->


  <div class="container" id="signIn">
    <h1 class="form-title">Sign In</h1>
    <form method="post" action="">
       
                <div class="input-group">
                    <i class='bx bxs-envelope'></i>
                    <input type="text" name="email" id="email" placeholder="Email" required>
                    <label for="fname">Email</label>
                </div>

                <div class="input-group">
                    <i class='bx bxs-lock-alt'></i>
                    <input type="text" name="password" id="password" placeholder="password" required>
                    <label for="password">password</label>
            

                <p class="recover">
                    <a href="#">Recover Password</a>
                </p>
           <input type="submit" class="btn" value="Sign In" name="Sign In">
            </form>
       
    </form>
    <div class="links">
        <p>Dont't Have Account?</p>
        <button id="signUpButton">Sign Up</button>
    </div>
 </div>






<script src="Formscript.js"></script>

</body>
</html>


























    <!-- SignUp Form -->
    <!-- <div class="form-Signup">
        <div class="form-box">
    <form action="">
        <h1>Sign Up</h1>
        <div class="input-box">
    <label for="fname">First Name</label><br>
    <input type="text" id="fname" name="firstname" placeholder="Your name" required><br>
    <i class='bx bxs-user'></i>
    <br>
    <label for="lname">Last Name</label><br>
    <input type="text" id="lname" name="lastname" placeholder="Your lastname" required><br>
    <i class='bx bxs-user'></i>
    <br>
    <label for="uname">Email</label><br>
    <input type="text" id="uname" name="email" placeholder="Email" required><br>
    <i class='bx bxs-envelope'></i>
    <br>
    <label for="password">Password:</label><br>
    <input type="password" name="password" placeholder="Password" required><br>
    <i class='bx bxs-lock-alt'></i>
   <br>
    
    <label for="phnumber">Phone Number:</label><br>
    <select>
        <option>251</option>
        <option>977</option> 
    </select>
    <input type="phone" name="telephone-number" placeholder="Phone Number"><br>
    <br> 
    <!-- <label for="country">Country</label><br> 
    <select id="country" name="country">
        <option value="australia">Ethiopia</option>
        <option value="canada">Canada</option>
        <option value="usa">USA</option>
    </select>-->

    <!-- <br><br>
    <div> -->
        <!--<input type="submit" value="Submit"/>-->

<!-- button type="submit">Sign Up</button><br>
<div class="login-Signup">
    <p>Already have an account?<a href="#" class="Signup">Login</a>
    </p>
</div>
<br> 
 <!-- <div class="login">
    <a href="login.html"> login</a> -->
 
    <!-- </div>
    </div>
    
</div>
</form>
</div>
</div> --> 


