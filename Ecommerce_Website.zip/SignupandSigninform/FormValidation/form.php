<?php
if(!isset($uername)){
    $username = '';
}
?>



<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>PHP Form Validation</title>
</head>
<body>
<link rel="stylesheet" href="style.css">
</head>
<body>
  <div class="header">
        <h2>SignUp</h2>
  </div>
        
  <form method="POST" action="validation.php">
        
        <div class="input-group">
          <label>Firstname</label>
          <input type="text" name="username"    value="<?php echo htmlspecialchars($username) ?>"><br/>
          <?php if(isset($name_error)){?>
            <p><?php echo $name_error ?></p>
           <?php } ?>
          
            
        </div>
        <div class="input-group">
          <label>Lastname</label>
          <input type="text" name="username"    value="<?php echo htmlspecialchars($username) ?>"><br/>
          <?php if(isset($name_error)){?>
            <p><?php echo $name_error ?></p>
           <?php } ?>
          
            
        </div>
        <div class="input-group">
          <label>Email</label>
          <input type="email" name="email" ><br/>
          <?php if(isset($email_error)){?>
            <p><?php echo $email_error ?></p>
           <?php } ?>


          <!-- value="<?php echo $email; ?>"> -->
        </div>
        <div class="input-group">
          <label>Password</label>
          <input type="password" name="password"><br/>
          <?php if(isset($password_error)){?>
            <p><?php echo $password_error ?></p>
           <?php } ?>

        </div>
        <!-- <div class="input-group">
          <label>Confirm password</label>
          <input type="password" name="password_2">
        </div> -->
        <div class="input-group">
          <button type="submit" class="btn" name="reg_user">Register</button>
        </div>
        <div class="links">
         <p>Already Have Account?</p>
                
                 <button id="signInBtn"> <a href="login.php">Sign In</a></button>
                 </div>
  </form>
</body>
</html>
  
