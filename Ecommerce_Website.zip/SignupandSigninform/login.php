<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>login</title>
    <link rel="stylesheet" href="Rstyle.css">
</head>
<body>
       <!-- Sign In Form -->


  <div class="container" id="signIn">
    <h1 class="form-title">Sign In</h1>
    <form method="post" action="">
       
                <div class="input-group">
                    <i class='bx bxs-envelope'></i>
                    <input type="text" name="email" id="email" placeholder="Email" required>
                    <label for="fname">Email</label>
                </div>

                <div class="input-group">
                    <i class='bx bxs-lock-alt'></i>
                    <input type="text" name="password" id="password" placeholder="password" required>
                    <label for="password">password</label>
            

                <p class="recover">
                    <a href="#">Recover Password</a>
                </p>
           <input type="submit" class="btn" value="Sign In" name="Sign In">
            </form>
       
    </form>
    <div class="links">
        <p>Dont't Have Account?</p>
        <button id="signInButton"><a href="index.html">Sign Up</a></button>
    </div>
 </div>






<script src="eco.js"></script>

</body>
</html>

