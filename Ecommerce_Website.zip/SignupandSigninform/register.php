<?php
include 'connect.php';


if(isset($_POST['signUp'])){
$Firstname =$_POST['fName'];
$Lastname = $_POST['lName'];
$Email = $_POST['email'];
$Password = $_POST['password'];
$Password =md5($Password);

$checkEmail = "SELECT * From users where email='$Email'";
$result = $conn ->query($checkEmail);
if($result ->num_rows>0){
    echo "Email Address Already Exists !";
}
else{
    $inserQuery="INSERT INTO users(Firstname, Lastname, Email, Password)
     VALUES ('$Firstname', '$Lastname', '$Email', '$Password')";
  if($conn -> query($insertQuery) ==TRUE){
  header("location:Signup.php");
  }
else{
    echo "Error:" .$conn ->error;
}

}
// For SignIn Form

if(isset($_POST['signIn'])){

    $Email =$_POST['email'];
    $Password = $_POST['password'];
    $Password = md5($Password);

    $sql = "SELECT * FROM users WHERE email = '$Email' and password = $Password";

    $result = $conn ->query($sql);
    if($result -> num_rows>0){
        session_start();
        $row=$result -> fetch_assoc();
        $_SESSION['email']=$row['email'];
        header("Location:homepage.php");
        exit();
    }
    else{
        echo "Not Found, Incorrect Email or Password";
    }
}

}



?>